/**
 * Calculates levenshtein distance.
 * @param a
 * @param b
 */
export default function levenshtein(a: string, b: string): number;
