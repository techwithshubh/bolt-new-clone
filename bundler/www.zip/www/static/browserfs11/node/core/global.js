"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @hidden
 */
var toExport = typeof (window) !== 'undefined' ? window : typeof (self) !== 'undefined' ? self : global;
exports.default = toExport;
//# sourceMappingURL=global.js.map