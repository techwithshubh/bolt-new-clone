module.exports = BrowserFS.BFSRequire('buffer').Buffer;
