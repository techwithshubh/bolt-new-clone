module.exports = BrowserFS.BFSRequire('process');
